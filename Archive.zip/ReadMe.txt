﻿Unit Test Instruction :  Please Run FundAnalysisTest.java for test cases

There are two methods buildDummyDataList() and buildDummyDateList() which are used to prepare dummy data and called in setUp() method to be used.

Build/Run Application Instruction : This Application is built in Java 8. Please use jdk 1.8 and import as existing maven project. 
Please run CsvWriteReadTest.java class to run the application

Approach : 
Read Fund.csv file and construct fundList
Read FundReturnSeries.csv and BenchmarkReturnSeries.csv and construct a hashMap respectively which has ‘code’ as key and a returnSeries list as value which has the same code as key.
Loop through fund list and for every fundSeries Code and its related benchmarkSeries code prepare a MonthlyOutPerformance list where fundSeries date is same as benchmarkSeries date. Also compute excess and Out Performance to set it in MonthlyOutPerformance list
Sort MonthlyOutPerformance list in reverse date order
Filter sublist from MonthlyOutPerformance list based on date
Sort the sublist in reverse Return value and set the Rank value.
