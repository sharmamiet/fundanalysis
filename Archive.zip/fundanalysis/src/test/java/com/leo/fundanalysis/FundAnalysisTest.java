package com.leo.fundanalysis;

import static org.junit.Assert.assertEquals;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import org.junit.Before;
import org.junit.Test;
import com.leo.fundanalysis.algorithm.MonthlyPerformanceFactory;
import com.leo.fundanalysis.constant.AppConstant;
import com.leo.fundanalysis.domain.MonthlyOutPerformance;

/**
 * Unit test for simple App.
 */
public class FundAnalysisTest {
	double fundReturnVal;
	double bmReturnVal;
	double excess;
	String outPerformanace;
	MonthlyPerformanceFactory factory = new MonthlyPerformanceFactory();
	List<MonthlyOutPerformance> mopList = null;
	List<LocalDate> dateList = null;

	@Before
	public void setUp() {
		mopList = buildDummyDataList();
		dateList = buildDummyDateList();
	}

	@Test
	public void testCalculateExcess() {
		fundReturnVal = -4.229084292;
		bmReturnVal = 1.309476266;
		excess = -5.538560558;
		assertEquals(excess, factory.calculateExcess(fundReturnVal, bmReturnVal), 0.01);
	}

	@Test
	public void testCalculateOutPerformance() {
		excess = -5.538560558;
		outPerformanace = AppConstant.UNDERPERFORMED;
		assertEquals(outPerformanace, factory.calculateOutPerformance(excess));
	}

	@Test
	public void testSortListByReturnToSetRank() {
		List<MonthlyOutPerformance> finalList = factory.sortListByReturnToSetRank(mopList, dateList); 
		
		assertEquals(3.87, finalList.get(0).getFundReturn(),0.0);
		assertEquals(1, finalList.get(0).getRank());
		
		assertEquals(2.74, finalList.get(1).getFundReturn(),0.0);
		assertEquals(2, finalList.get(1).getRank());
		
		assertEquals(-2.24, finalList.get(2).getFundReturn(),0.0);
		assertEquals(1, finalList.get(2).getRank());
		
		assertEquals(8.07, finalList.get(3).getFundReturn(),0.0);
		assertEquals(1, finalList.get(3).getRank());
		
		assertEquals(0.71, finalList.get(4).getFundReturn(),0.0);
		assertEquals(2, finalList.get(4).getRank());
		
		assertEquals(1.22, finalList.get(5).getFundReturn(),0.0);
		assertEquals(1, finalList.get(5).getRank());
	}
	
	public List<MonthlyOutPerformance> buildDummyDataList() {
		MonthlyOutPerformance junMonth = new MonthlyOutPerformance("Vanguard Wholesale",LocalDate.parse("2016-06-30"),3.03,"Out Performed",1.22);
		MonthlyOutPerformance novMonthVanguard = new MonthlyOutPerformance("Pengana Global", LocalDate.parse("2016-11-30"), 4.00, "Out Performed", 3.87);
		MonthlyOutPerformance novMonthPengana = new MonthlyOutPerformance("Vanguard Australian",LocalDate.parse("2016-11-30"),2.87,"Out Performed",2.74);
		MonthlyOutPerformance julMonthVanguard = new MonthlyOutPerformance("Vanguard Wholesale",LocalDate.parse("2016-07-31"),-0.02, "", 0.71);
		MonthlyOutPerformance julMonthOldman = new MonthlyOutPerformance("oldman Sachs", LocalDate.parse("2016-07-31"), 0.30, "", 8.07);
		MonthlyOutPerformance octMonthVanguard = new MonthlyOutPerformance("Vanguard Australian", LocalDate.parse("2016-10-31"), 2.39, "Out Performed", -2.24);

		List<MonthlyOutPerformance> list = new ArrayList<MonthlyOutPerformance>();
		list.add(junMonth);
		list.add(novMonthPengana);
		list.add(novMonthVanguard);
		list.add(julMonthVanguard);
		list.add(julMonthOldman);
		list.add(octMonthVanguard);

		return list;
	}

	public List<LocalDate> buildDummyDateList() {
		List<LocalDate> dateList = new ArrayList<LocalDate>();
		dateList.add(LocalDate.parse("2016-11-30"));
		dateList.add(LocalDate.parse("2016-10-31"));
		dateList.add(LocalDate.parse("2016-07-31"));
		dateList.add(LocalDate.parse("2016-06-30"));
		return dateList;
	}
}
