package com.leo.fundanalysis.main;

import java.io.IOException;
import java.util.List;
import com.leo.fundanalysis.domain.MonthlyOutPerformance;
import com.leo.fundanalysis.io.CsvFileReader;
import com.leo.fundanalysis.io.CsvFileWriter;

/**
 * @author rachna
 */
public class CsvWriteReadTest {

	/**
	 * 
	 * Run the Program using Main method
	 * 
	 * @param args
	 */
    public static void main(String[] args) throws IOException {
        String funds = System.getProperty("user.home") + "/Documents/TestData/fund.csv";
        String fundReturnSeries = System.getProperty("user.home") + "/Documents/TestData/fundReturnSeries.csv";
        String benchReturnSeries = System.getProperty("user.home") + "/Documents/TestData/benchReturnSeries.csv";
        String outputFile = System.getProperty("user.home") + "/Documents/TestData/MonthlyOutPerformance.csv";
        
        List<MonthlyOutPerformance> monthlyOutPerformance = CsvFileReader.readCsvFiles(funds, fundReturnSeries, benchReturnSeries);
        CsvFileWriter.writeCsvFile(outputFile, monthlyOutPerformance);
    }

}
