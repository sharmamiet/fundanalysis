package com.leo.fundanalysis.domain;

import java.time.LocalDate;

/**
 * @author rachna
 */
public class ReturnSeries {
	private String code;
	private LocalDate date;
	private double returnVal;

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public LocalDate getDate() {
		return date;
	}

	public void setDate(LocalDate date) {
		this.date = date;
	}

	public double getReturnVal() {
		return returnVal;
	}

	public void setReturnVal(double returnVal) {
		this.returnVal = returnVal;
	}

	public String toString() {
		return "[ ReturnSeries : code = " + code + " date = " + date + " ReturnSeries = " + returnVal + " ]";
	}
}
