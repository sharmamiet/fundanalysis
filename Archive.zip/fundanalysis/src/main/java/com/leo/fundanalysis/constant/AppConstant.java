package com.leo.fundanalysis.constant;

/**
 * @author rachna
 */
public class AppConstant {
	public static final String COMMA_DELIMITER = ",";
	public static final String NEW_LINE_SEPARATOR = "\n";
	public static final String FILE_HEADER = "FundName,Date,Excess,OutPerformance,Return,Rank";
	public static final String BENCHMARK = "BENCHMARK";
	public static final String FUND = "FUND";
	public static final String OUTPERFORMED = "Out Performed";
	public static final String UNDERPERFORMED = "Under Performed";
	public static final String BLANK = "";
	public static final int CODE = 0;
	public static final int FUND_NAME = 1;
	public static final int BENCHMARK_CODE = 2;
	public static final int DATE = 1;
	public static final int RETURN_PERC = 2;
}
