package com.leo.fundanalysis.utility;

import java.io.FileReader;
import java.io.LineNumberReader;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import com.leo.fundanalysis.constant.AppConstant;
import com.leo.fundanalysis.domain.Funds;
import com.leo.fundanalysis.domain.ReturnSeries;

public class BuilderUtil {

	private static Set<LocalDate> DATESET = new HashSet<LocalDate>();

	/**
	 * Convert the Fund.csv file into List for fast retrieval
	 * 
	 * @param arr
	 * @return
	 */
	public static List<Funds> buildListFromFundFile(String fileName) {
		String line;
		List<Funds> funds = new ArrayList<Funds>();
		try (LineNumberReader fileReader = new LineNumberReader(new FileReader(fileName))) {
			fileReader.readLine();
			while ((line = fileReader.readLine()) != null) {
				String[] tokens = line.split(AppConstant.COMMA_DELIMITER);
				if (tokens.length > 0) {
					Funds fund = new Funds();
					fund.setFundCode(tokens[AppConstant.CODE]);
					fund.setFundName(tokens[AppConstant.FUND_NAME]);
					fund.setBenchmarkCode(tokens[AppConstant.BENCHMARK_CODE]);
					funds.add(fund);
				}
			}
		} catch (Exception e) {
			System.out.println("Error in CsvFileReader !!!");
		}
		return funds;
	}

	/**
	 * This method reads returnseries csv file and creates an instance of ReturnSeries class for every line then add it to returnList
	 * It also creates a HashSet 'codeSet' for ReturnSeries's code field and 'DATESET' for every date in the benchmarkReturn csv
	 * then loop through codeSet to create a HashMap which has 'code' as Key and 'returnList' as value
	 * 
	 * @param arr
	 * @return
	 */
	public static Map<String, List<ReturnSeries>> buildMapFromReturnSeriesFile(String fileName, DateTimeFormatter format, String fileType) {
		String line;
		Map<String, List<ReturnSeries>> map = new HashMap<String, List<ReturnSeries>>();
		List<ReturnSeries> returnList = new ArrayList<ReturnSeries>();
		Set<String> codeSet = new HashSet<String>();

		try (LineNumberReader fileReader = new LineNumberReader(new FileReader(fileName))) {
			fileReader.readLine();
			while ((line = fileReader.readLine()) != null) {
				String[] tokens = line.split(AppConstant.COMMA_DELIMITER);
				if (tokens.length > 0) {
					String code = tokens[AppConstant.CODE];
					codeSet.add(code);
					ReturnSeries returnSeries = new ReturnSeries();
					returnSeries.setCode(code);
					LocalDate localDate = LocalDate.parse(tokens[AppConstant.DATE], format);
					if(!fileType.isEmpty() && fileType.equals(AppConstant.BENCHMARK))
						DATESET.add(localDate);
					
					returnSeries.setDate(localDate);
					returnSeries.setReturnVal(Double.parseDouble((tokens[AppConstant.RETURN_PERC])));
					returnList.add(returnSeries);
				}
			}
		} catch (Exception e) {
			System.out.println("Error in CsvFileReader !!!");
		}
		
		codeSet.forEach(code -> {
			List<ReturnSeries> returnSeriesList = new ArrayList<ReturnSeries>();
			returnList.forEach(returnSeries -> {
				if (!code.isEmpty() && code.equals(returnSeries.getCode())) {
					returnSeriesList.add(returnSeries);
				}
			});
			map.put(code, returnSeriesList);
		});
		return map;
	}
	
	/**
	 * this method convert the 'DATESET' into List<LocalDate> and sort it in reverse order
	 * 
	 * @param 
	 * @return
	 */
	public static List<LocalDate> retrieveFundDateList(){
		List<LocalDate> dateList = DATESET.parallelStream().collect(Collectors.toList());
		dateList.sort(Collections.reverseOrder());
		return dateList;
	}
}
