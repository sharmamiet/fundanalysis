package com.leo.fundanalysis.io;

import java.io.FileWriter;
import java.util.List;
import java.util.stream.Collectors;

import com.leo.fundanalysis.constant.AppConstant;
import com.leo.fundanalysis.domain.MonthlyOutPerformance;

public class CsvFileWriter {
	// Delimiter used in CSV file

	/**
	 * Generates the output as csv file using monthlyOutPerformance list
	 * 
	 * @param fileName,
	 *         monthlyOutPerformance
	 * @return
	 */
	public static void writeCsvFile(String fileName, List<MonthlyOutPerformance> monthlyOutPerformance) {
		try (FileWriter fileWriter = new FileWriter(fileName)) {
			fileWriter.append(AppConstant.FILE_HEADER);
			fileWriter.append(AppConstant.NEW_LINE_SEPARATOR);
			String result = monthlyOutPerformance.stream().map(monthlyOutPerformanceObj -> {
				StringBuilder sb = new StringBuilder();
				sb.append(String.valueOf(monthlyOutPerformanceObj.getFundName()));
				sb.append(AppConstant.COMMA_DELIMITER);
				sb.append(String.valueOf(monthlyOutPerformanceObj.getDate()));
				sb.append(AppConstant.COMMA_DELIMITER);
				sb.append(String.format("%.2f", monthlyOutPerformanceObj.getExcess()));
				sb.append(AppConstant.COMMA_DELIMITER);
				sb.append(String.valueOf(monthlyOutPerformanceObj.getOutPerformance()));
				sb.append(AppConstant.COMMA_DELIMITER);
				sb.append(String.format("%.2f", monthlyOutPerformanceObj.getFundReturn()));
				sb.append(AppConstant.COMMA_DELIMITER);
				sb.append(String.valueOf(monthlyOutPerformanceObj.getRank()));
				sb.append(AppConstant.NEW_LINE_SEPARATOR);
				return sb.toString();
			}).collect(Collectors.joining());
			fileWriter.append(result);
		} catch (Exception e) {
			System.out.println("Error in CsvFileWriter !!!");
			e.printStackTrace();
		}

	}
}
