package com.leo.fundanalysis.domain;

import java.time.LocalDate;

/**
 * @author rachna
 */

public class MonthlyOutPerformance {
	private String fundCode;
	private String fundName;
	private double excess;
	private LocalDate date;
	private double fundReturn;
	private String outPerformance;
	private int rank;

	public MonthlyOutPerformance(String fundName, LocalDate date, double excess, String outPerformance, double fundReturn){
		this.fundName = fundName;
		this.date = date;
		this.excess = excess;
		this.outPerformance = outPerformance;
		this.fundReturn = fundReturn;
	}
	
	public MonthlyOutPerformance(){}
	
	public String getFundCode() {
		return fundCode;
	}

	public void setFundCode(String fundCode) {
		this.fundCode = fundCode;
	}

	public double getFundReturn() {
		return fundReturn;
	}

	public void setFundReturn(double fundReturn) {
		this.fundReturn = fundReturn;
	}

	public String getFundName() {
		return fundName;
	}

	public void setFundName(String fundName) {
		this.fundName = fundName;
	}

	public double getExcess() {
		return excess;
	}

	public void setExcess(double excess) {
		this.excess = excess;
	}

	public void setExcess(int excess) {
		this.excess = excess;
	}

	public LocalDate getDate() {
		return date;
	}

	public void setDate(LocalDate date) {
		this.date = date;
	}

	public String getOutPerformance() {
		return outPerformance;
	}

	public void setOutPerformance(String outPerformance) {
		this.outPerformance = outPerformance;
	}

	public int getRank() {
		return rank;
	}

	public void setRank(int rank) {
		this.rank = rank;
	}

	public String toString() {
		return "[ MonthlyOutPerformance : FundName = "+fundName + " date = " + date + " excess = " + excess + " OutPerformance = " + outPerformance + " FundReturnSeries = " + fundReturn+" ]";
	}
}
